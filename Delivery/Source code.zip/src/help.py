def displayHelp () :
    print("python3 ./main.py [argument]")
    print("\t-h | --h | -help : display help")
    print("\t-n 3 : create array of 3 per 3")
    print("\t-n 4 : create array of 4 per 4")
    print("\t-g : graphic version")